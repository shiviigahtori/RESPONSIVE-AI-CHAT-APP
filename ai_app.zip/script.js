// Bot configurations
const bots = {
  chatgpt: {
    name: "ChatGPT",
    avatar: "🤖",
    status: "Online",
    reply: async (message) => {
      await new Promise(r => setTimeout(r, 1000));
      return "ChatGPT: " + message.split("").reverse().join("");
    }
  },
  gemini: {
    name: "Gemini",
    avatar: "🔮",
    status: "Online",
    reply: async (message) => {
      await new Promise(r => setTimeout(r, 1200));
      return "Gemini: " + message.toUpperCase();
    }
  },
  claude: {
    name: "Claude",
    avatar: "🦉",
    status: "Online",
    reply: async (message) => {
      await new Promise(r => setTimeout(r, 1100));
      return "Claude: " + message.toLowerCase();
    }
  },
  bing: {
    name: "Bing",
    avatar: "🧠",
    status: "Online",
    reply: async (message) => {
      await new Promise(r => setTimeout(r, 900));
      return "Bing: " + message.replace(/[aeiou]/gi, '*');
    }
  },
  llama: {
    name: "Llama",
    avatar: "🦙",
    status: "Online",
    reply: async (message) => {
      await new Promise(r => setTimeout(r, 950));
      return "Llama: " + message.split(" ").reverse().join(" ");
    }
  }
};

let activeBot = "chatgpt";
let isDark = false;

// DOM elements
const themeToggle = document.getElementById('themeToggle');
const mobileToggle = document.getElementById('mobileToggle');
const leftPanel = document.getElementById('leftPanel');
const conversations = document.getElementById('conversations');
const chatAvatar = document.getElementById('chatAvatar');
const chatTitle = document.getElementById('chatTitle');
const chatContainer = document.getElementById('chatContainer');
const chatInput = document.getElementById('chatInput');
const sendBtn = document.getElementById('sendBtn');
const attachBtn = document.getElementById('attachBtn');
const emojiBtn = document.getElementById('emojiBtn');
const fileInput = document.getElementById('fileInput');
const typingIndicator = document.getElementById('typingIndicator');

// Theme toggle
themeToggle.addEventListener('click', () => {
  isDark = !isDark;
  document.body.classList.toggle('dark', isDark);
  themeToggle.textContent = isDark ? '☀️' : '🌙';
  localStorage.setItem('darkMode', isDark);
});

// Load saved theme
const savedTheme = localStorage.getItem('darkMode');
if (savedTheme === 'true') {
  isDark = true;
  document.body.classList.add('dark');
  themeToggle.textContent = '☀️';
}

// Mobile toggle
mobileToggle.addEventListener('click', () => {
  leftPanel.classList.toggle('open');
});

// Bot selection
conversations.addEventListener('click', (e) => {
  const item = e.target.closest('.conversation-item');
  if (!item) return;

  // Update active state
  conversations.querySelectorAll('.conversation-item').forEach(el => {
    el.classList.remove('active');
  });
  item.classList.add('active');

  // Switch bot
  activeBot = item.dataset.bot;
  const bot = bots[activeBot];
  chatAvatar.textContent = bot.avatar;
  chatTitle.textContent = bot.name;

  // Load chat history
  loadChatHistory();

  // Close mobile panel
  leftPanel.classList.remove('open');
});

// Add message to chat
function addMessage(content, sender, timestamp = null) {
  const messageGroup = document.createElement('div');
  messageGroup.className = `message-group ${sender}`;

  const message = document.createElement('div');
  message.className = `message ${sender}`;
  
  const time = timestamp || new Date().toLocaleTimeString([], { 
    hour: '2-digit', 
    minute: '2-digit' 
  });

  message.innerHTML = `
    ${content}
    <div class="message-time">${time}</div>
  `;

  messageGroup.appendChild(message);
  chatContainer.appendChild(messageGroup);
  chatContainer.scrollTop = chatContainer.scrollHeight;
}

// Send message
async function sendMessage() {
  const content = chatInput.value.trim();
  if (!content) return;

  // Add user message
  addMessage(content, 'user');
  chatInput.value = '';
  saveChatHistory();

  // Show typing indicator
  typingIndicator.style.display = 'block';
  chatContainer.scrollTop = chatContainer.scrollHeight;

  try {
    // Get bot reply
    const reply = await bots[activeBot].reply(content);
    
    // Hide typing indicator and add bot message
    setTimeout(() => {
      typingIndicator.style.display = 'none';
      addMessage(reply, 'bot');
      saveChatHistory();
    }, 500);
  } catch (error) {
    typingIndicator.style.display = 'none';
    addMessage('Sorry, I encountered an error. Please try again.', 'bot');
  }
}

// Event listeners
sendBtn.addEventListener('click', sendMessage);

chatInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    sendMessage();
  }
});

// Auto-resize textarea
chatInput.addEventListener('input', function() {
  this.style.height = 'auto';
  this.style.height = this.scrollHeight + 'px';
});

// File attachment
attachBtn.addEventListener('click', () => {
  fileInput.click();
});

fileInput.addEventListener('change', (e) => {
  const file = e.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = function(e) {
    const img = document.createElement('img');
    img.src = e.target.result;
    img.style.maxWidth = '200px';
    img.style.borderRadius = '12px';
    
    addMessage(img.outerHTML, 'user');
    saveChatHistory();
  };
  reader.readAsDataURL(file);
});

// Emoji picker (simple)
emojiBtn.addEventListener('click', () => {
  const emojis = ['😀', '😂', '😍', '👍', '❤️', '🔥', '🎉', '👏'];
  const emoji = emojis[Math.floor(Math.random() * emojis.length)];
  chatInput.value += emoji;
  chatInput.focus();
});

// Save chat history
function saveChatHistory() {
  const messages = [];
  chatContainer.querySelectorAll('.message-group').forEach(group => {
    const message = group.querySelector('.message');
    const isUser = group.classList.contains('user');
    const content = message.innerHTML.split('<div class="message-time">')[0];
    const time = message.querySelector('.message-time')?.textContent || '';
    
    messages.push({
      content,
      sender: isUser ? 'user' : 'bot',
      time
    });
  });

  const allChats = JSON.parse(localStorage.getItem('chatHistory') || '{}');
  allChats[activeBot] = messages;
  localStorage.setItem('chatHistory', JSON.stringify(allChats));
}

// Load chat history
function loadChatHistory() {
  const allChats = JSON.parse(localStorage.getItem('chatHistory') || '{}');
  const messages = allChats[activeBot] || [];

  chatContainer.innerHTML = '';
  
  if (messages.length === 0) {
    // Default welcome message
    addMessage(`Hello! I'm ${bots[activeBot].name}. How can I assist you today?`, 'bot');
  } else {
    messages.forEach(msg => {
      addMessage(msg.content, msg.sender, msg.time);
    });
  }
}

// Initialize
loadChatHistory();
